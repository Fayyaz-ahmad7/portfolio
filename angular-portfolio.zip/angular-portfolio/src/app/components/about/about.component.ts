import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-about',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.scss']
})
export class AboutComponent {
  stats = signal([
    { number: '42+', label: 'Projects Completed', icon: 'grid_view' },
    { number: '28+', label: 'Happy Clients', icon: 'sentiment_very_satisfied' },
    { number: '15+', label: 'Tech Mastered', icon: 'terminal' },
    { number: '7+', label: 'Years Experience', icon: 'history_edu' }
  ]);
}
