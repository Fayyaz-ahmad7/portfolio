import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-experience',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './experience.component.html',
  styleUrls: ['./experience.component.scss']
})
export class ExperienceComponent {
  experiences = signal([
    {
      role: 'Lead Frontend Architect',
      company: 'TechVanguard Solutions',
      period: '2023 - Present',
      description: 'Spearheaded migration of core corporate SaaS products to standalone components and Angular Signals, reducing overall application overhead by 30%.'
    },
    {
      role: 'Senior Angular Developer',
      company: 'PixelForge Studios',
      period: '2021 - 2023',
      description: 'Constructed responsive dashboards with complex RxJS state flows and custom charts. Implemented modern token-based dark themes.'
    },
    {
      role: 'Frontend Engineer',
      company: 'Nexus Web Labs',
      period: '2019 - 2021',
      description: 'Developed highly fluid responsive mockups, integrated secure HTTP interceptors, and configured offline caching databases.'
    }
  ]);

  education = signal([
    {
      degree: 'M.S. in Software Engineering',
      institution: 'Tech University',
      period: '2017 - 2019',
      description: 'Focused on high-fidelity user-interface algorithms, component encapsulation architecture, and distributed services.'
    },
    {
      degree: 'B.S. in Computer Science',
      institution: 'National College of IT',
      period: '2013 - 2017',
      description: 'Acquired foundational training in compiler design, system networks, data structures, and standard web engineering.'
    }
  ]);
}
