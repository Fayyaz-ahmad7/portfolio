import { Component, computed, signal } from '@angular/core';
import { CommonModule } from '@angular/common';

interface Project {
  title: string;
  category: string;
  description: string;
  tags: string[];
  liveUrl: string;
  githubUrl: string;
}

@Component({
  selector: 'app-projects',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './projects.component.html',
  styleUrls: ['./projects.component.scss']
})
export class ProjectsComponent {
  categories = signal(['All', 'Dashboards', 'E-Commerce', 'SaaS', 'Core Libraries']);
  selectedCategory = signal('All');

  allProjects = signal<Project[]>([
    {
      title: 'Apex Admin Console',
      category: 'Dashboards',
      description: 'A premium, fully-responsive enterprise dashboard featuring real-time telemetry, signal-powered widgets, multi-tenant caching, and customizable charts.',
      tags: ['Angular', 'RxJS', 'Tailwind CSS', 'ApexCharts'],
      liveUrl: '#',
      githubUrl: '#'
    },
    {
      title: 'Zenith E-Commerce Portal',
      category: 'E-Commerce',
      description: 'A high-speed shopping marketplace built with standalone route providers, lazy state loaded checkout flows, and Stripe API configurations.',
      tags: ['Angular 20', 'Signals', 'SCSS', 'Firebase'],
      liveUrl: '#',
      githubUrl: '#'
    },
    {
      title: 'Nebula SaaS Suite',
      category: 'SaaS',
      description: 'Real-time collaborative teamwork canvas featuring instant channels, direct reactive text chats, and persistent offline state caches.',
      tags: ['Angular', 'Firebase Firestore', 'Tailwind'],
      liveUrl: '#',
      githubUrl: '#'
    },
    {
      title: 'Ngx-Motion-UI Library',
      category: 'Core Libraries',
      description: 'An open-source performance-oriented hardware-accelerated transitions and interactive canvas library for modular Angular systems.',
      tags: ['Angular Lib', 'TypeScript', 'SCSS', 'Jest'],
      liveUrl: '#',
      githubUrl: '#'
    }
  ]);

  // Reactive computed value to automatically filter projects when category signal changes!
  filteredProjects = computed(() => {
    const currentCategory = this.selectedCategory();
    if (currentCategory === 'All') {
      return this.allProjects();
    }
    return this.allProjects().filter(p => p.category === currentCategory);
  });

  setFilter(category: string) {
    this.selectedCategory.set(category);
  }
}
