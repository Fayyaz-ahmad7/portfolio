import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-skills',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './skills.component.html',
  styleUrls: ['./skills.component.scss']
})
export class SkillsComponent {
  skills = signal([
    { name: 'Angular (20+ & Standalone)', percentage: '96%', icon: 'layers' },
    { name: 'TypeScript & JavaScript ES6', percentage: '94%', icon: 'code' },
    { name: 'RxJS State & Event Streams', percentage: '92%', icon: 'loop' },
    { name: 'Reactive & Responsive Forms', percentage: '95%', icon: 'assignment' },
    { name: 'Tailwind CSS, SCSS & CSS3', percentage: '98%', icon: 'palette' },
    { name: 'Firebase, Firestore & Auth', percentage: '88%', icon: 'cloud' },
    { name: 'RESTful API & HTTP Interceptors', percentage: '93%', icon: 'settings_ethernet' },
    { name: 'Git & Agile CI/CD Workflows', percentage: '90%', icon: 'merge_type' }
  ]);
}
