import { Component, Output, EventEmitter, OnInit, OnDestroy, signal } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-hero',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './hero.component.html',
  styleUrls: ['./hero.component.scss']
})
export class HeroComponent implements OnInit, OnDestroy {
  @Output() viewProjects = new EventEmitter<void>();
  @Output() hireMe = new EventEmitter<void>();

  words = ['Senior Angular Architect', 'Frontend Innovator', 'Reactive UI/UX Designer', 'Performance Tuning Expert'];
  typedText = signal('');
  private wordIndex = 0;
  private charIndex = 0;
  private isDeleting = false;
  private timer: any;

  ngOnInit() {
    this.typeEffect();
  }

  ngOnDestroy() {
    if (this.timer) clearTimeout(this.timer);
  }

  typeEffect() {
    const currentWord = this.words[this.wordIndex];
    if (!this.isDeleting) {
      if (this.charIndex < currentWord.length) {
        this.typedText.set(currentWord.substring(0, this.charIndex + 1));
        this.charIndex++;
        this.timer = setTimeout(() => this.typeEffect(), 100);
      } else {
        this.isDeleting = true;
        this.timer = setTimeout(() => this.typeEffect(), 1500); // pause before delete
      }
    } else {
      if (this.charIndex > 0) {
        this.typedText.set(currentWord.substring(0, this.charIndex - 1));
        this.charIndex--;
        this.timer = setTimeout(() => this.typeEffect(), 50);
      } else {
        this.isDeleting = false;
        this.wordIndex = (this.wordIndex + 1) % this.words.length;
        this.timer = setTimeout(() => this.typeEffect(), 200);
      }
    }
  }

  onViewProjects() {
    this.viewProjects.emit();
  }

  onHireMe() {
    this.hireMe.emit();
  }
}
