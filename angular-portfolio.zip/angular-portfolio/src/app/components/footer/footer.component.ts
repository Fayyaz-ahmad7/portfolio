import { Component, Output, EventEmitter, signal } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-footer',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent {
  @Output() scrollTop = new EventEmitter<void>();

  currentYear = signal(new Date().getFullYear());

  onScrollTop() {
    this.scrollTop.emit();
  }
}
