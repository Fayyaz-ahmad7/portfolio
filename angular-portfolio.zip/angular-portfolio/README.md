# Fayyaz Ahmad - Premium Angular Developer Portfolio

A modern, high-fidelity, and fully responsive personal portfolio website built with the latest **Angular (Standalone Components)**, **TypeScript**, **Angular Signals**, **Angular Router**, **SCSS**, and **Angular Animations**.

## Features

- **Premium UI/UX Design:** Built with a dark, sophisticated theme (#0F172A), glassmorphic elements, soft shadows, and clean gradients.
- **Modern Angular Architecture:** 100% Standalone Components, Angular Signals for state management, reactive forms with full validation, and optimized lazy loading.
- **High Performance:** Smooth SCSS animations, lazy-loaded components, and highly responsive layouts (Mobile-first, desktop-optimized).
- **Interactive Sections:**
  - Hero with animated typing effect and quick actions.
  - Interactive About Me with statistics counters.
  - Interactive Skills metrics with progress animations.
  - Project Filtering with smooth categories.
  - Interactive Contact Form with Angular Reactive Forms and custom validation.
  - Timeline and Testimonials slider.

---

## Quick Start & Local Setup

To run this Angular project locally on your machine, follow these steps:

### Prerequisites

Make sure you have Node.js and the Angular CLI installed:
- [Node.js](https://nodejs.org/) (v18.x or v20.x recommended)
- [Angular CLI](https://angular.dev/cli) (v18+)

Install the Angular CLI globally if you haven't already:
```bash
npm install -g @angular/cli
```

### Installation

1. Export/download this workspace as a ZIP file from the AI Studio top bar settings.
2. Extract the ZIP file and navigate to the `angular-portfolio` directory:
   ```bash
   cd angular-portfolio
   ```
3. Install the dependencies:
   ```bash
   npm install
   ```
4. Start the local development server:
   ```bash
   ng serve
   ```
5. Open your browser and navigate to `http://localhost:4200/` to view your premium portfolio live!

---

## Project Structure

```text
angular-portfolio/
├── src/
│   ├── app/
│   │   ├── components/       # Standalone reusable sections
│   │   │   ├── hero/         # Landing and animated heading
│   │   │   ├── about/        # Profile introduction & stats
│   │   │   ├── skills/       # Custom animated skill meters
│   │   │   ├── projects/     # Filterable project portfolio cards
│   │   │   ├── experience/   # Experience & Education timeline
│   │   │   ├── contact/      # Reactive validation form
│   │   │   └── footer/       # Footer with social connections
│   │   ├── app.component.ts  # Main shell container
│   │   ├── app.config.ts     # Global configurations (routing, animations)
│   │   └── app.routes.ts     # Type-safe routing definitions
│   ├── index.html            # Main HTML wrapper
│   ├── main.ts               # Core bootstrapper
│   └── styles.scss           # Custom design tokens & global CSS
├── angular.json              # Angular workspace configurations
├── package.json              # Dependency declarations
└── tsconfig.json             # TypeScript rules and compilation configuration
```
